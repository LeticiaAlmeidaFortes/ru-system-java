/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexao {
    public Conexao(){
        
    }
    
    public static Connection con = null;
    public static void conectar(){
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bdru","root","");
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
    }
    
}